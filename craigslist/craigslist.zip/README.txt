+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
+                                                                         +
+                                                                         +
+                   Craigslist Lost and Found Scraper                     +
+                                                                         +
+                                                                         +
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Pre-requisites:
1. Python 2.7 (make sure python is in your path)
2. Firefox and Geckodriver. (copy Geckodriver into C;/Python27)
3. Selenium for Python
4. bs4 for python

How to run?
1. Install all the pre-requisites.
2. Double click scrape.py to start the scraping.

Hey innovator1!

I've created a program to do the tasks you desired. Apologies for the list of pre-requisites being quite long. I can install all these for you over a TeamViewer session if needed.

In case you face any issues or need modifications to the functionality please let me know. I'll be more than happy to help you with that!

Thanks again for your order! Looking forward to working with you again.

Regards
Archit.
